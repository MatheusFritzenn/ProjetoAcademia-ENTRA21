﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    internal class SqlConnector
    {
        public const string CONNECTION_STRING = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\moc\Desktop\AcademiaZYX\Sql\Sql\Sql\Sql\AcademiaZYXdb.mdf;Integrated Security=True;Connect Timeout=5";
    }
}

